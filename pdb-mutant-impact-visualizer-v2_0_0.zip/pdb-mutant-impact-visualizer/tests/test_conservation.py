import pytest

from pdb_mutant_impact_visualizer.conservation import ConservationError, alignment_column_metrics, map_pdb_residue_to_uniprot


def test_alignment_column_metrics_reports_counts_and_entropy():
    aligned = ">sp|P12345|QUERY\nAC-D\n>sp|P2|HIT\nAT-D\n>sp|P3|HIT\nAT-D\n"
    metrics = alignment_column_metrics(aligned, "P12345", 2)
    assert metrics["query_amino_acid"] == "C"
    assert metrics["column_coverage_count"] == 3
    assert metrics["residue_counts"] == {"C": 1, "T": 2}
    assert metrics["shannon_entropy_bits"] == pytest.approx(0.918296)
    assert "not a ConSurf grade" in metrics["method"]


class Response:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        pass

    def json(self):
        return self.payload


class MappingSession:
    def get(self, url, timeout):
        return Response({"1abc": {"UniProt": {"P12345": {"mappings": [
            {"chain_id": "A", "start": {"author_residue_number": 10},
             "end": {"author_residue_number": 20}, "unp_start": 100, "unp_end": 110}
        ]}}}})


def test_sifts_mapping_converts_author_position_to_uniprot_position():
    assert map_pdb_residue_to_uniprot("1ABC", "A", 15, session=MappingSession()) == ("P12345", 105)


def test_sifts_ambiguous_or_missing_map_is_rejected():
    class Empty:
        def get(self, url, timeout):
            return Response({"1abc": {"UniProt": {}}})
    with pytest.raises(ConservationError, match="unambiguous"):
        map_pdb_residue_to_uniprot("1ABC", "A", 15, session=Empty())
